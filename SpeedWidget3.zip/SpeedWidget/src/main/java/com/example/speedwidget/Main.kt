package com.example.speedwidget

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView
import java.util.Locale

// ---------------------------------------------------------------
// الشاشة الرئيسية: بتطلب الصلاحيات وبتشغّل المراقبة
// ---------------------------------------------------------------
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#0F1720"))
        }

        val title = TextView(this).apply {
            text = "ويدجت سرعة النت (v3)"
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.START
        }

        val help = TextView(this).apply {
            text = "1) اضغط «تشغيل المراقبة» ووافق على الصلاحيات.\n\n" +
                "2) اضغط مطولًا على مكان فاضي في الشاشة الرئيسية ← الويدجت ← «سرعة النت» وضيفه.\n\n" +
                "لو اسم الواي فاي ظاهر «غير معروف»: شغّل الموقع (GPS) وخلّي صلاحية الموقع للتطبيق «السماح دائمًا» أو «أثناء الاستخدام».\n\n" +
                "بعد إعادة تشغيل التليفون افتح التطبيق مرة عشان المراقبة ترجع تشتغل."
            setTextColor(Color.parseColor("#B0BEC5"))
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }

        val startBtn = Button(this).apply {
            text = "تشغيل المراقبة"
            setOnClickListener { startMonitoring() }
        }
        val stopBtn = Button(this).apply {
            text = "إيقاف المراقبة"
            setOnClickListener { stopService(Intent(this@MainActivity, SpeedService::class.java)) }
        }

        root.addView(title)
        root.addView(help)
        root.addView(startBtn)
        root.addView(stopBtn)
        setContentView(root)

        startMonitoring()
    }

    private fun startMonitoring() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            startForegroundService(Intent(this, SpeedService::class.java))
        } else {
            requestPermissions(missing.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startForegroundService(Intent(this, SpeedService::class.java))
    }
}

// ---------------------------------------------------------------
// الويدجت نفسه: بيتعرض على الشاشة، والخدمة هي اللي بتحدّثه كل ثانية
// ---------------------------------------------------------------
class SpeedWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_speed)
            val pi = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.root, pi)
            manager.updateAppWidget(id, views)
        }
    }
}

// ---------------------------------------------------------------
// الخدمة: بتحسب السرعة وبتجيب بيانات الشبكة وبتحدّث الويدجت كل ثانية
// ---------------------------------------------------------------
class SpeedService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastTime = 0L

    private val ticker = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                // نكمل حتى لو حصل خطأ في لحظة معينة
            }
            handler.postDelayed(this, 1000)
        }
    }

    // نوقف الحساب لما الشاشة تقفل عشان نوفّر البطارية
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_ON) startTicking() else stopTicking()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("speed", "مراقبة السرعة", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, "speed")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("مراقبة سرعة الإنترنت شغالة")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }

        registerReceiver(
            screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
        )
        startTicking()
    }

    override fun onDestroy() {
        stopTicking()
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    private fun startTicking() {
        handler.removeCallbacks(ticker)
        lastRx = TrafficStats.getTotalRxBytes()
        lastTx = TrafficStats.getTotalTxBytes()
        lastTime = SystemClock.elapsedRealtime()
        handler.postDelayed(ticker, 1000)
    }

    private fun stopTicking() {
        handler.removeCallbacks(ticker)
    }

    private fun tick() {
        // 1) السرعة
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val seconds = (now - lastTime).coerceAtLeast(1L) / 1000.0
        val down = if (rx >= 0 && lastRx >= 0 && rx >= lastRx) (rx - lastRx) / seconds else 0.0
        val up = if (tx >= 0 && lastTx >= 0 && tx >= lastTx) (tx - lastTx) / seconds else 0.0
        lastRx = rx
        lastTx = tx
        lastTime = now

        // 2) نوع الاتصال واسم الشبكة والجودة
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)

        var type = "لا يوجد اتصال"
        var name = "—"
        var level = 0

        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            type = "واي فاي"
            try {
                val wm = applicationContext.getSystemService(WifiManager::class.java)
                @Suppress("DEPRECATION")
                val info = wm.connectionInfo
                val ssid = info?.ssid?.trim('"')
                name = if (ssid.isNullOrBlank() || ssid == "<unknown ssid>") "غير معروف (فعّل الموقع)" else ssid
                val rssi = info?.rssi ?: -127
                level = when {
                    rssi >= -55 -> 4
                    rssi >= -67 -> 3
                    rssi >= -78 -> 2
                    rssi >= -90 -> 1
                    else -> 0
                }
            } catch (e: Exception) {
                name = "غير معروف"
            }
        } else if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            type = "بيانات الموبايل"
            try {
                val tm = getSystemService(TelephonyManager::class.java)
                name = tm.networkOperatorName.takeIf { it.isNotBlank() } ?: "شبكة الموبايل"
                level = tm.signalStrength?.level ?: 0
            } catch (e: SecurityException) {
                name = "شبكة الموبايل"
            }
        } else if (caps != null) {
            type = "متصل"
        }

        val quality = when {
            caps == null -> "لا إشارة"
            level >= 4 -> "ممتازة"
            level == 3 -> "جيدة"
            level == 2 -> "متوسطة"
            level == 1 -> "ضعيفة"
            else -> "لا إشارة"
        }

        // 3) تحديث الويدجت
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, SpeedWidgetProvider::class.java))
        if (ids.isEmpty()) return

        val views = RemoteViews(packageName, R.layout.widget_speed)
        views.setTextViewText(R.id.tvDown, "↓ " + formatSpeed(down))
        views.setTextViewText(R.id.tvUp, "↑ " + formatSpeed(up))
        views.setTextViewText(R.id.tvType, type)
        views.setTextViewText(R.id.tvName, name)
        views.setTextViewText(R.id.tvQuality, quality)

        val onColor = when {
            level >= 3 -> 0xFF2ECC71.toInt()
            level == 2 -> 0xFFF1C40F.toInt()
            else -> 0xFFE74C3C.toInt()
        }
        val offColor = 0xFF3A4654.toInt()
        val bars = intArrayOf(R.id.bar1, R.id.bar2, R.id.bar3, R.id.bar4)
        bars.forEachIndexed { i, barId ->
            views.setInt(barId, "setBackgroundColor", if (i < level) onColor else offColor)
        }

        manager.partiallyUpdateAppWidget(ids, views)
    }

    private fun formatSpeed(bytesPerSec: Double): String {
        return if (bytesPerSec >= 1024 * 1024) {
            String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024 * 1024))
        } else {
            String.format(Locale.US, "%.0f KB/s", bytesPerSec / 1024)
        }
    }
}
